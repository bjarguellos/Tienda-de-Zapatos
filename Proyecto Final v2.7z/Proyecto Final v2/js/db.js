const sql = require('mssql');

const config = {
    user: 'PC-ASDFGH', // Cambia esto por tu usuario de SQL Server
    password: 'Qwerty1357$', // Cambia esto por tu contraseña de SQL Server
    server: 'localhost', // Cambia esto si tu servidor está en otra dirección
    database: 'TiendaZapatos',
    options: {
        encrypt: false, // Cambia a true si estás usando Azure
        trustServerCertificate: true, // Cambia esto según tu configuración
        // trustedConnection: true // Usa esto si estás usando autenticación de Windows
    }
};

async function connectToDatabase() {
    try {
        await sql.connect(config);
        console.log('Conectado a la base de datos');
    } catch (err) {
        console.error('Error al conectar a la base de datos:', err);
    }
}

module.exports = { sql, connectToDatabase };