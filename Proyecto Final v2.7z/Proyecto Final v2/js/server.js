const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { sql, connectToDatabase } = require('./db');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// Conectar a la base de datos
connectToDatabase();

// Ruta de prueba para verificar la conexión
app.get('/api/test', async (req, res) => {
    try {
        const result = await sql.query('SELECT 1 AS Test');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Iniciar el servidor
app.listen(port, () => {
    console.log(`Servidor iniciado en el puerto ${port}`);
});