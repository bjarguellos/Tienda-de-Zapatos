// Simulación de rol de usuario
const userRole = 'admin'; // Cambia a 'standard' para simular un usuario estándar

// Mostrar opciones de administrador si el rol es 'admin'
if (userRole === 'admin') {
    document.getElementById('admin-options').style.display = 'block';
}

// Simulación de verificación de usuario registrado
document.getElementById('loginForm').onsubmit = function(event) {
    event.preventDefault(); // Evitar el envío del formulario para la simulación
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Aquí deberías hacer una llamada a tu backend para verificar el usuario
    // Simulación de un usuario registrado
    const registeredUsers = ['usuario@example.com']; // Ejemplo de usuarios registrados

    if (registeredUsers.includes(email)) {
        document.getElementById('error-message').innerText = 'El usuario ya está registrado.';
        document.getElementById('error-message').style.display = 'block';
    } else {
        // Aquí iría la lógica para iniciar sesión
        alert('Iniciando sesión...');
    }
};

// Simulación de registro de usuario
document.getElementById('registerForm').onsubmit = function(event) {
    event.preventDefault(); // Evitar el envío del formulario para la simulación
    const cedula = document.getElementById('cedula').value;
    const tipoDocumento = document.getElementById('tipo-documento').value;
    const pais = document.getElementById('pais').value;
    const nombreCompleto = document.getElementById('nombre-completo').value;
    const fechaNacimiento = document.getElementById('fecha-nacimiento').value;
    const nacionalidad = document.getElementById('nacionalidad').value;
    const sexo = document.getElementById('sexo').value;
    const direccion = document.getElementById('direccion').value;
    const telefono = document.getElementById('telefono').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Aquí deberías hacer una llamada a tu backend para registrar el usuario
    // Simulación de un usuario registrado
    const registeredUsers = ['usuario@example.com']; // Ejemplo de usuarios registrados

    if (registeredUsers.includes(email)) {
        document.getElementById('error-message').innerText = 'El usuario ya está registrado.';
        document.getElementById('error-message').style.display = 'block';
    } else {
        // Aquí iría la lógica para registrar al usuario
        alert('Usuario registrado exitosamente.');
    }
};